# Marvin v3: placeholders to fill

Every real-data slot in the decks comes from two files: `src/data-en.json` (English) and `src/data-it.json` (Italian).
To fill one, put the text in its `"value"` field (in both files), then run `python3 src/build.py`.
An empty `value` is shown on screen as a dashed amber box: `[REAL DATA: …]` / `[DATO REALE: …]`.
Entries marked TO CONFIRM show `[TO CONFIRM: …]` / `[DA CONFERMARE: …]` (plus a suggestion, if any): confirm or replace.
Slide 8 lists are open-ended: add `running_3`, `owner_5`, `next_3`… (with a `term`) to both files and a new row appears.
The speaker notes (in `body-en.html` / `body-it.html`) repeat the same placeholders in square brackets: update them too.

Open: 25 of 27 keys.

## Slide 6 · Proof

| # | Key | Type | On screen (EN) | What Riccardo must provide | Suggestion | Filled EN / IT |
|---|---|---|---|---|---|---|
| 1 | `framing` | TO CONFIRM | [TO CONFIRM: weeks or days] | One framing for the whole talk: '[weeks or days] of development become hours of flow runs'. Used in slide 6 and in the notes. |  | no / no |
| 2 | `ace_credem` | TO CONFIRM | [TO CONFIRM: was the IBM ACE project a CREDEM project?] | Yes / no, and in one line what it was (anonymized if needed). |  | no / no |
| 3 | `ace_baseline` | REAL DATA | [REAL DATA: human-only baseline, in days] | The real estimate or actual for doing it without the flow, and where the number comes from. |  | no / no |
| 4 | `ace_flow_time` | TO CONFIRM | [TO CONFIRM: flow run time] | Wall-clock time of the epic-stories flow run. v1 said about 2 hours: confirm or correct. | ~2 h | no / no |
| 5 | `ace_human_hours` | REAL DATA | [REAL DATA: human hours spent on plan and review] | Time people spent writing/approving the plan and reading review findings, so the 2 h is not read as the whole cost. |  | no / no |
| 6 | `cobol_done` | REAL DATA | [REAL DATA: what is done so far] | Modules / scope of the COBOL-J2EE migration completed to date. |  | no / no |
| 7 | `cobol_equivalent` | REAL DATA | [REAL DATA: what is proven equivalent (replay)] | What has passed replay of recorded behaviour, and how many cases. |  | no / no |
| 8 | `cobol_inprogress` | REAL DATA | [REAL DATA: what is in progress now] | Current module / wave. |  | no / no |
| 9 | `cobol_next` | REAL DATA | [REAL DATA: next milestone and date] | The next date the sponsors can hold you to. |  | no / no |

## Slide 7 · Cost and control

| # | Key | Type | On screen (EN) | What Riccardo must provide | Suggestion | Filled EN / IT |
|---|---|---|---|---|---|---|
| 10 | `cost_run` | REAL DATA | [REAL DATA: cost per run, and what it includes] | E.g. model/API cost per run, compute, licences. Say what is and isn't included. |  | no / no |
| 11 | `code_where` | REAL DATA | [REAL DATA: where the code goes] | Which endpoint/region the agent sends code to, under which contract. |  | no / no |
| 12 | `data_where` | REAL DATA | [REAL DATA: where the data goes, and which data agents see] | Production data? Anonymized samples? Recorded behaviour: where it is stored. |  | no / no |
| 13 | `perimeter_out` | TO CONFIRM | [TO CONFIRM: what leaves the bank's perimeter] | Confirm with security/compliance. |  | no / no |
| 14 | `perimeter_in` | TO CONFIRM | [TO CONFIRM: what stays inside] | Repository, records, approvals, data: confirm. |  | no / no |
| 15 | `approver` | TO CONFIRM | [TO CONFIRM: who approves, at which gate] | Roles (or names, if agreed) for each approval gate. | a named person at plan, specification and merge | no / no |

## Slide 8 · Owners and the ask

| # | Key | Type | On screen (EN) | What Riccardo must provide | Suggestion | Filled EN / IT |
|---|---|---|---|---|---|---|
| 16 | `running_1` | REAL DATA | Running today: [REAL DATA: what is running at CREDEM today (flow, module, team)] | One line per item; add running_3, running_4... to add rows. |  | no / no |
| 17 | `running_2` | REAL DATA | Agent in use: [REAL DATA: agent in use] | Already known: Gemini CLI. |  | yes / yes |
| 18 | `owner_1` | REAL DATA | WMF modernization: [REAL DATA: owner] | Already known. |  | yes / yes |
| 19 | `owner_2` | REAL DATA | Sponsor: [REAL DATA: MD / CIO sponsor (name, role)] | As you want it on screen. |  | no / no |
| 20 | `owner_3` | TO CONFIRM | Compliance: [TO CONFIRM: compliance owner] | Name if already agreed; otherwise this is part of the ask. |  | no / no |
| 21 | `owner_4` | REAL DATA | Plan & spec approval: [REAL DATA: who approves plans and specifications] | Role(s). |  | no / no |
| 22 | `next_1` | REAL DATA | Next milestone: [REAL DATA: next milestone and date] | Same as slide 6 if applicable. |  | no / no |
| 23 | `next_2` | REAL DATA | Next check-in: [REAL DATA: next check-in with sponsors (date)] | When the room hears from you next. |  | no / no |
| 24 | `ask_main` | REAL DATA | [REAL DATA: the decision we ask for today, and by when] | One sentence. This is the visual focus of the last slide. |  | no / no |
| 25 | `ask_opt1` | TO CONFIRM | [TO CONFIRM: approve the next module (name it)] | Option for the ask: confirm, reword or delete. |  | no / no |
| 26 | `ask_opt2` | TO CONFIRM | [TO CONFIRM: name a compliance owner for the runs] | Option for the ask: confirm, reword or delete. |  | no / no |
| 27 | `ask_opt3` | TO CONFIRM | [TO CONFIRM: two more people on the team] | Option for the ask: confirm, reword or delete. |  | no / no |

No numbers, costs, dates, names or results appear in the decks except through these keys (Gemini CLI and Riccardo's own role are pre-filled).
