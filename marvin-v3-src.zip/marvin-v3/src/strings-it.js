window.MARVIN_L = (() => {
  const L = {
    "Notes": "Note",
    "Nothing yet.": "Ancora niente.",
    // slide 2
    "task": "task", "from a spec": "da una spec", "agent": "agente", "coder": "sviluppatore",
    "someone checks": "qualcuno controlla", "later": "dopo", "spec": "spec", "done ✓": "fatto ✓",
    "All done. Everything works!": "Tutto fatto. Funziona tutto!",
    "It wasn't: the tests never ran": "Non era vero: i test non sono mai partiti",
    "clear": "chiaro", "fuzzy": "sfocato", "fading": "sbiadito", "gone": "perso",
    "…what was the goal again?": "…qual era l'obiettivo, scusa?",
    // slide 3
    "plan": "piano", "code": "codice", "checks": "controlli", "review": "review", "commit": "commit",
    "your build": "la tua build", "the tasks, in order": "i task, in ordine",
    "Gap found: a missing test": "Lacuna trovata: manca un test",
    "round 1: one gap, sent back as a revision": "giro 1: una lacuna, rimandata come revisione",
    "Revision: add the missing test": "Revisione: aggiungi il test mancante",
    "revised": "rivisto", "clean": "pulita",
    "round 1: one gap · round 2: cleared": "giro 1: una lacuna · giro 2: risolta",
    "one commit per reviewed task": "un commit per ogni task revisionato",
    "back as a revision": "torna indietro come revisione",
    // slide 4
    "draft plan": "bozza del piano", "you": "tu", "a person": "una persona", "build": "build",
    "stories, who owns which files, in what order": "story: chi possiede quali file, in che ordine",
    "Read the plan, then decide": "Leggi il piano, poi decidi",
    "Revising, your edits stay": "Lo rivedo, le tue modifiche restano",
    "revision 2: your edits kept": "revisione 2: le tue modifiche restano",
    "approved": "approvato", "approved as written": "approvato così com'è", "built": "costruito",
    // slide 5
    "lays the ground": "prepara la base", "owns its files": "possiede i suoi file", "after 2–4": "dopo la 2–4",
    "epic": "epic", "one branch": "un solo branch",
    "in parallel · each in its own copy of the repo": "in parallelo · ognuna nella sua copia del repo",
    "merged": "integrata", "Judge: gap found, revision added": "Giudice: lacuna trovata, aggiunta una revisione",
    "5/5 merged": "5/5 integrate",
    // slide 7
    "survey": "ricognizione", "extract": "estrazione", "rules · scenarios": "regole · scenari", "approve": "approva",
    "seed": "avvio", "implement": "implementa", "verify": "verifica", "replay": "replay",
    "legacy side": "lato legacy", "new side": "lato nuovo", "clean room": "clean room",
    "inventory": "inventario", "Approve the spec to cross the wall": "Approva la spec per superare il muro",
    "scaffold": "scheletro", "replayed": "rieseguito", "Recorded behaviour replayed": "Comportamento registrato rieseguito",
    // slide 8
    "decision": "decisione", "yours": "vostra", "Your decision": "La vostra decisione"
  }
  for (let i = 1; i <= 5; i++) { L[`step ${i}`] = `passo ${i}`; L[`story ${i}`] = `story ${i}` }
  return L
})()
