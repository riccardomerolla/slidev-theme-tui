;(() => {
  "use strict"
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches
  const SPEED = reduce ? 0.02 : 1
  const Cancel = Symbol("cancel")
  const L = window.MARVIN_L || {}
  const tr = (t, v) => { if (t == null) return t; let r = L[t] ?? t; if (v) for (const k in v) r = r.split(`{${k}}`).join(v[k]); return r }
  const $ = (s, r = document) => r.querySelector(s)
  const $$ = (s, r = document) => [...r.querySelectorAll(s)]
  const stage = $("#stage")
  const slides = $$(".slide", stage)
  const N = slides.length
  let SCALE = 1

  const ICONS = {
    star: '<svg viewBox="0 0 24 24"><path d="M12 1.5c.7 5.6 3.4 8.5 10.5 10.5-7.1 2-9.8 4.9-10.5 10.5C11.3 16.9 8.6 14 1.5 12 8.6 10 11.3 7.1 12 1.5z"/></svg>',
    fail: '<svg viewBox="0 0 24 24"><path d="M8 2h8l6 6v8l-6 6H8l-6-6V8zm2.1 5L7 10.1 8.9 12 7 13.9 10.1 17 12 15.1 13.9 17 17 13.9 15.1 12 17 10.1 13.9 7 12 8.9z"/></svg>',
    human: '<svg viewBox="0 0 24 24"><circle cx="12" cy="7.5" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4.2" height="16" rx="1.2"/><rect x="13.8" y="4" width="4.2" height="16" rx="1.2"/></svg>'
  }
  const ARROW = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.3 4.3a1 1 0 0 1 1.4 0l7 7a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4-1.4l5.3-5.3H3a1 1 0 1 1 0-2h15.6l-5.3-5.3a1 1 0 0 1 0-1.4z"/></svg>'
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e }
  const fmt = (sim) => { const s = Math.round(sim); return `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, "0")}s` }
  const rel = (node, base) => { const a = node.getBoundingClientRect(), b = base.getBoundingClientRect(); return { x: (a.left - b.left) / SCALE, y: (a.top - b.top) / SCALE, w: a.width / SCALE, h: a.height / SCALE } }

  /* ── node (after visual-effect's EffectNode) ── */
  function makeNode(name, sub, opts = {}) {
    name = tr(name); sub = tr(sub)
    const root = el("div", "ve" + (opts.h ? " h" : ""))
    const bubble = el("div", "ve-bubble"); bubble.hidden = true
    const box = el("div", "ve-box"), shine = el("div", "ve-shine"), content = el("div", "ve-content")
    box.append(shine, content)
    const label = el("div", "ve-label"), nm = el("span", "ve-name", name), sb = el("span", "ve-sub", sub || ""), time = el("span", "ve-time")
    label.append(nm); if (sub != null) label.append(sb); label.append(time)
    root.append(bubble, box, label)
    let raf = 0, t0 = 0, bt = 0
    const stopTimer = () => { cancelAnimationFrame(raf); raf = 0 }
    const tick = () => { time.textContent = fmt(((performance.now() - t0) / 1000) * 240); raf = requestAnimationFrame(tick) }
    const pop = (n) => { if (!reduce && n) n.animate([{ transform: "scale(.5)", opacity: 0, filter: "blur(8px)" }, { transform: "scale(1)", opacity: 1, filter: "blur(0)" }], { duration: 460, easing: "cubic-bezier(.34,1.56,.64,1)" }) }
    const icon = (k) => { content.innerHTML = `<span class="ve-icon">${ICONS[k]}</span>`; pop(content.firstChild) }
    const width = (w) => { box.style.width = `${w}px` }
    const hideBubble = () => { clearTimeout(bt); bubble.hidden = true }
    const showBubble = (text, kind, ms) => {
      clearTimeout(bt)
      bubble.className = `ve-bubble ${kind}`; bubble.textContent = text; bubble.hidden = false
      if (!opts.h) {
        bubble.style.left = "0px"; bubble.style.setProperty("--tip", "42px")
        const card = root.closest(".card")
        if (card) {
          const cr = card.getBoundingClientRect(), r = bubble.getBoundingClientRect()
          const over = (r.right - (cr.right - 16 * SCALE)) / SCALE
          if (over > 0) { bubble.style.left = `${-over}px`; bubble.style.setProperty("--tip", `${42 + over}px`) }
        }
      }
      if (!reduce) bubble.animate([{ opacity: 0, scale: ".9" }, { opacity: 1, scale: "1" }], { duration: 260, easing: "cubic-bezier(.34,1.56,.64,1)" })
      if (ms) bt = setTimeout(() => { bubble.hidden = true }, ms * SPEED + (reduce ? 0 : 0))
    }
    const shake = () => { if (!reduce) box.animate([0, 8, -8, 6, -6, 3, 0].map((x, i) => ({ transform: `translateX(${x}px) rotate(${i % 2 ? 4 : -4}deg)` })), { duration: 480, easing: "ease-out" }) }
    const api = {
      root, box,
      idle() { stopTimer(); hideBubble(); time.textContent = ""; box.dataset.state = "idle"; width(84); icon("star") },
      run() { hideBubble(); box.dataset.state = "running"; width(84); content.innerHTML = ""; t0 = performance.now(); stopTimer(); if (!reduce) tick() },
      done(text) { stopTimer(); hideBubble(); time.textContent = ""; box.dataset.state = "done"; const s = el("span", null, tr(text)); content.innerHTML = ""; content.append(s); width(Math.max(84, s.scrollWidth + 40)); pop(s) },
      fail(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "failed"; icon("fail"); shake(); showBubble(tr(msg), "fail") },
      wait(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "human"; width(84); icon("human"); showBubble(tr(msg), "human") },
      interrupt(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "interrupted"; icon("pause"); shake(); showBubble(tr(msg), "interrupted") },
      note(msg, ms = 1800) { showBubble(tr(msg), "note", ms) },
      hide: hideBubble,
      flash() { if (!reduce) box.animate([{ filter: "brightness(2)" }, { filter: "brightness(1)" }], { duration: 560 }) },
      label(t) { nm.textContent = tr(t) }, sublabel(t) { sb.textContent = tr(t) }
    }
    api.idle()
    return api
  }

  /* ── simulated presenter cursor ── */
  const cursor = $("#cursor")
  let cursorPos = { x: 1500, y: 900 }
  async function clickOn(btn, c) {
    const r = rel(btn, stage)
    const tx = r.x + r.w * 0.6, ty = r.y + r.h * 0.62
    if (!reduce) {
      cursor.style.transition = "none"
      cursor.style.transform = `translate(${cursorPos.x}px,${cursorPos.y}px)`
      cursor.classList.add("on")
      await c.sleep(60)
      cursor.style.transition = "transform .75s cubic-bezier(.5,0,.2,1), opacity .3s"
      cursor.style.transform = `translate(${tx}px,${ty}px)`
      await c.sleep(800)
      cursor.classList.remove("click"); void cursor.offsetWidth; cursor.classList.add("click")
    }
    cursorPos = { x: tx, y: ty }
    btn.classList.add("pressed")
    await c.sleep(220)
    btn.classList.remove("pressed")
    if (!reduce) setTimeout(() => cursor.classList.remove("on"), 700)
  }


  /* ── placeholders: every real-data slot comes from data-<lang>.json ── */
  const DATA = window.MARVIN_DATA || {}
  const META = DATA._meta || { real: "REAL DATA", confirm: "TO CONFIRM", suggested: "suggested" }
  const esc = (t) => String(t).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[m])
  // Lists: <div data-list="owner_"> renders one row per data key starting with "owner_" (add a key to add a row).
  for (const box of $$("[data-list]")) {
    const pre = box.dataset.list
    Object.keys(DATA).filter((k) => k.startsWith(pre)).forEach((k, i) => {
      const r = el("div", "lrow"); r.dataset.r = `${pre}${i + 1}`
      r.innerHTML = `<dt>${esc(DATA[k].term || "")}</dt><dd><span data-ph="${k}"></span></dd>`
      box.append(r)
    })
  }
  for (const e of $$("[data-ph]")) {
    const d = DATA[e.dataset.ph]
    if (!d) { e.textContent = `[MISSING KEY: ${e.dataset.ph}]`; e.classList.add("ph"); continue }
    if (d.value) { e.textContent = d.value; e.classList.add("filled"); continue }
    e.classList.add("ph")
    const kind = d.kind === "confirm" || d.suggestion ? META.confirm : META.real
    e.innerHTML = `<span class="ph-l">[${esc(kind)}: ${esc(d.label)}]</span>` + (d.suggestion ? `<span class="ph-s">${esc(META.suggested)}: ${esc(d.suggestion)}</span>` : "")
    e.title = d.hint || ""
  }

  /* ── run context per slide ── */
  function makeRun(slide, scenario) {
    let gen = 0
    const nodes = []
    const c = {
      root: slide,
      node(name, sub, opts) { const n = makeNode(name, sub, opts); nodes.push(n); return n },
      arrow() { return el("div", "arrow", ARROW) },
      chain(parent, list) { list.forEach((n, i) => { if (i) parent.append(c.arrow()); parent.append(n.root) }) },
      sleep(ms) { const g = gen; return new Promise((res, rej) => setTimeout(() => (g === gen ? res() : rej(Cancel)), ms * SPEED)) },
      async press(btn, waitMs = 1600) {
        const g = gen
        btn.disabled = false; btn.classList.add("ready")
        await c.sleep(waitMs)
        await clickOn(btn, c)
        if (g !== gen) throw Cancel
        btn.disabled = true; btn.classList.remove("ready"); btn.classList.add("used")
      },
      reveal(sel) { $$(sel, slide).forEach((e) => e.classList.add("shown")) },
      async revealAll(sel, ms = 320) { for (const e of $$(sel, slide)) { e.classList.add("shown"); await c.sleep(ms) } },
      art(file, note, list) {
        list = list || $("[data-arts]", slide); if (!list) return
        const empty = $(".empty", list); if (empty) empty.remove()
        let li = [...list.children].find((x) => x.dataset.file === file)
        if (!li) { li = el("li"); li.dataset.file = file; list.append(li) }
        li.innerHTML = `<span class="f">${tr(file)}</span><span class="n">${tr(note)}</span>`
        li.classList.remove("fresh"); void li.offsetWidth; li.classList.add("fresh")
      },
      reset() {
        gen++
        nodes.forEach((n) => n.idle())
        $$("[data-approve],[data-back],[data-rerun]", slide).forEach((b) => { b.disabled = true; b.classList.remove("ready", "pressed", "used") })
        $$("[data-arts]", slide).forEach((l) => (l.innerHTML = `<li class="empty">${tr("Nothing yet.")}</li>`))
        $$(".shown", slide).forEach((e) => e.classList.remove("shown"))
        cursor.classList.remove("on")
        scenario.reset && scenario.reset(c)
      }
    }
    scenario.build && scenario.build(c)
    c.reset()
    return {
      async play() {
        c.reset(); slide.dataset.settled = "0"
        const g = gen
        try { await c.sleep(scenario.delay ?? 900); await scenario.run(c) } catch (e) { if (e !== Cancel) console.error(e) }
        if (g === gen) slide.dataset.settled = "1"
      },
      stop() { c.reset(); slide.dataset.settled = "0" }
    }
  }

  /* ── scenarios, keyed by slide number ── */
  const S = {}
  const G = "Gemini CLI"

  // 1 · title: type the quote
  S[1] = {
    delay: 500,
    reset(c) { $(".quote .t", c.root).textContent = "" },
    async run(c) {
      const q = $(".quote", c.root), t = $(".t", q), txt = q.dataset.type
      if (reduce) { t.textContent = txt; return }
      for (let i = 1; i <= txt.length; i++) { t.textContent = txt.slice(0, i); await c.sleep(txt[i - 1] === "," ? 260 : 32) }
    }
  }

  // 2 · the problem (two illustrations, no numbers)
  S[2] = {
    build(c) {
      const [a, b] = $$("[data-row]", c.root)
      this.a = [c.node("task", "from a spec"), c.node("agent", "coder"), c.node("someone checks", "later")]
      c.chain(a, this.a)
      this.b = [1, 2, 3, 4, 5].map((i) => c.node(`step ${i}`))
      c.chain(b, this.b)
      this.fill = $("[data-fill]", c.root); this.pct = $("[data-pct]", c.root)
    },
    reset() { if (this.fill) { this.fill.style.width = "100%"; this.fill.classList.remove("low"); this.pct.textContent = tr("clear") } },
    async run(c) {
      const left = async () => {
        const [task, agent, chk] = this.a
        task.done("spec"); await c.sleep(500)
        agent.run(); await c.sleep(1600)
        agent.done("done ✓"); agent.note("All done. Everything works!", 2100)
        await c.sleep(2200)
        chk.run(); await c.sleep(1100)
        chk.fail("It wasn't: the tests never ran")
      }
      const right = async () => {
        await c.sleep(400)
        const words = ["clear", "clear", "fuzzy", "fading", "fading", "gone"]
        for (let i = 0; i < 5; i++) {
          const n = this.b[i]
          n.run(); await c.sleep(850)
          this.fill.style.width = `${100 - (i + 1) * 18}%`; this.pct.textContent = tr(words[i + 1])
          if (i >= 2) this.fill.classList.add("low")
          if (i < 4) n.done("✓"); else n.fail("…what was the goal again?")
        }
      }
      await Promise.all([left(), right()])
    }
  }

  // 3 · the basic loop (hero), no figures
  S[3] = {
    build(c) {
      this.row = $("[data-row]", c.root); this.viz = this.row.parentElement
      this.n = [c.node("plan", G), c.node("code", G), c.node("checks", "your build"), c.node("review", G), c.node("commit")]
      c.chain(this.row, this.n)
      this.svg = $("[data-arc]", c.root); this.path = $("path", this.svg); this.text = $("text", this.svg)
      this.svg.insertAdjacentHTML("afterbegin", '<defs><marker id="ah" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#f87171"/></marker></defs>')
      this.path.setAttribute("marker-end", "url(#ah)")
    },
    reset() { this.path.classList.remove("on"); this.text.classList.remove("on") },
    arc() {
      const a = rel(this.n[3].box, this.viz), b = rel(this.n[1].box, this.viz), lab = rel(this.n[3].root, this.viz)
      const y = lab.y + lab.h + 12, x1 = a.x + a.w / 2, x2 = b.x + b.w / 2
      this.path.setAttribute("d", `M ${x1} ${y} C ${x1} ${y + 60}, ${x2} ${y + 60}, ${x2} ${y + 4}`)
      this.text.setAttribute("x", (x1 + x2) / 2 - 70); this.text.setAttribute("y", y + 72); this.text.textContent = tr("back as a revision")
      this.path.classList.add("on"); this.text.classList.add("on")
    },
    async run(c) {
      const [plan, code, checks, review, commit] = this.n
      plan.run(); await c.sleep(1000); plan.done("plan.md"); c.art("plan.md", "the tasks, in order")
      code.run(); await c.sleep(1300); code.done("diff")
      checks.run(); await c.sleep(900); checks.done("✓")
      review.run(); await c.sleep(1100); review.fail("Gap found: a missing test")
      c.art("findings.md", "round 1: one gap, sent back as a revision")
      this.arc()
      await c.sleep(2000)
      checks.idle(); review.idle()
      code.run(); code.note("Revision: add the missing test", 1600)
      await c.sleep(1300); code.done("revised")
      this.path.classList.remove("on"); this.text.classList.remove("on")
      checks.run(); await c.sleep(800); checks.done("✓")
      review.run(); await c.sleep(1000); review.done("clean"); c.art("findings.md", "round 1: one gap · round 2: cleared")
      commit.run(); await c.sleep(700); commit.done("commit"); c.art("git commit", "one commit per reviewed task")
    }
  }

  // 4 · the plan is a document
  S[4] = {
    build(c) {
      this.n = [c.node("draft plan", G), c.node("you", "a person"), c.node("build", G)]
      c.chain($("[data-row]", c.root), this.n)
      this.yes = $("[data-approve]", c.root); this.no = $("[data-back]", c.root)
    },
    async run(c) {
      const [draft, you, build] = this.n
      draft.run(); await c.sleep(1200); draft.done("plan.md"); c.art("plan.md", "stories, who owns which files, in what order")
      you.wait("Read the plan, then decide")
      this.yes.disabled = false; this.yes.classList.add("ready")
      await c.press(this.no, 1800)
      this.yes.disabled = true; this.yes.classList.remove("ready")
      you.idle(); draft.run(); draft.note("Revising, your edits stay", 1500)
      await c.sleep(1400); draft.done("plan.md v2"); c.art("plan.md", "revision 2: your edits kept")
      you.wait("Read the plan, then decide")
      await c.press(this.yes, 1700)
      you.done("approved"); c.art("plan.md ✓", "approved as written")
      build.run(); await c.sleep(1500); build.done("built")
      await c.revealAll("[data-r]", 300)
    }
  }

  // 5 · parallel stories + any agent in the seat
  S[5] = {
    build(c) {
      const dag = $("[data-dag]", c.root), h = { h: true }
      this.s = [c.node("story 1", "lays the ground", h), c.node("story 2", "owns its files", h), c.node("story 3", "owns its files", h), c.node("story 4", "owns its files", h), c.node("story 5", "after 2–4", h)]
      this.epic = c.node("epic", "one branch", h)
      const lanes = el("div", "lanes")
      lanes.append(el("div", "lanes-cap", tr("in parallel · each in its own copy of the repo")))
      this.s.slice(1, 4).forEach((n) => lanes.append(n.root))
      dag.append(this.s[0].root, c.arrow(), lanes, c.arrow(), this.s[4].root, c.arrow(), this.epic.root)
    },
    async run(c) {
      const [s1, s2, s3, s4, s5] = this.s, epic = this.epic
      epic.run(); s1.run(); await c.sleep(1200); s1.done("merged")
      await Promise.all([
        (async () => { s2.run(); await c.sleep(1700); s2.done("merged") })(),
        (async () => { s3.run(); await c.sleep(1100); s3.fail("Judge: gap found, revision added"); await c.sleep(1700); s3.run(); await c.sleep(1100); s3.done("merged") })(),
        (async () => { s4.run(); await c.sleep(2100); s4.done("merged") })()
      ])
      s5.run(); await c.sleep(1200); s5.done("merged")
      epic.done("5/5 merged")
      await c.revealAll("[data-r]", 300)
    }
  }

  // 6 · proof: rows fill in
  S[6] = { delay: 700, async run(c) { await c.revealAll("[data-r]", 260) } }

  // 7 · cost and control: the clean-room crossing, then the answers
  S[7] = {
    build(c) {
      const row = $("[data-row]", c.root)
      const mk = (cap, list) => { const s = el("div", "side"); const r = el("div", "row"); c.chain(r, list); s.append(el("span", "side-cap", tr(cap)), r); return s }
      this.l = [c.node("survey", G), c.node("extract", "rules · scenarios"), c.node("you", "approve")]
      this.t = [c.node("seed"), c.node("implement", G), c.node("verify", "replay")]
      this.wall = el("div", "wall", `<span>${tr("clean room")}</span>`)
      row.append(mk("legacy side", this.l), this.wall, mk("new side", this.t))
      this.yes = $("[data-approve]", c.root)
    },
    reset() { this.wall.classList.remove("pulse") },
    async run(c) {
      const [survey, extract, you] = this.l, [seed, impl, verify] = this.t
      c.revealAll("[data-r]", 250).catch(() => {})
      survey.run(); await c.sleep(1000); survey.done("inventory")
      extract.run(); await c.sleep(1200); extract.done("spec")
      you.wait("Approve the spec to cross the wall")
      await c.press(this.yes, 1500)
      you.done("approved")
      this.wall.classList.remove("pulse"); void this.wall.offsetWidth; this.wall.classList.add("pulse")
      seed.run(); await c.sleep(700); seed.done("scaffold")
      impl.run(); await c.sleep(1300); impl.done("built")
      verify.run(); await c.sleep(1200); verify.done("replayed")
      verify.note("Recorded behaviour replayed", 2000)
      await c.sleep(600)
    }
  }

  // 8 · owners + the ask: the run stops for a person, the room
  S[8] = {
    build(c) { this.h = c.node("decision", "yours"); $("[data-asknode]", c.root).append(this.h.root) },
    async run(c) {
      await c.revealAll(".owners [data-r]", 220)
      this.h.wait("Your decision"); c.reveal('[data-r="ask"]')
      await c.sleep(1200)
    }
  }

  const runs = slides.map((s, i) => (S[i + 1] ? makeRun(s, S[i + 1]) : null))

  /* ── starfield with parallax ── */
  const cv = $("#stars"), ctx = cv.getContext("2d"), neb = $(".nebula")
  let stars = [], W = 0, H = 0, off = 0, target = 0, last = 0
  function seed() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    W = cv.width = Math.floor(innerWidth * dpr); H = cv.height = Math.floor(innerHeight * dpr)
    let r = 1337; const rnd = () => ((r = (r * 16807) % 2147483647) / 2147483647)
    stars = Array.from({ length: Math.round((innerWidth * innerHeight) / 5200) }, () => {
      const z = rnd() ** 2 * 0.9 + 0.1
      return { x: rnd() * W, y: rnd() * H, z, r: (0.4 + z * 1.4) * dpr, p: rnd() * 6.28, g: rnd() < 0.12 }
    })
  }
  function draw(t) {
    ctx.clearRect(0, 0, W, H)
    for (const s of stars) {
      let x = (s.x - off * s.z * 3) % W; if (x < 0) x += W
      const tw = reduce ? 0.8 : 0.55 + 0.45 * Math.sin(t / 900 + s.p)
      ctx.globalAlpha = (0.25 + s.z * 0.75) * tw
      ctx.fillStyle = s.g ? "#9ff5b8" : "#e8eef7"
      ctx.beginPath(); ctx.arc(x, s.y, s.r, 0, 6.283); ctx.fill()
    }
    ctx.globalAlpha = 1
  }
  function loop(t) { off += (target - off) * 0.05; draw(t); last = requestAnimationFrame(loop) }
  seed()
  if (reduce) draw(0); else requestAnimationFrame(loop)

  /* ── deck ── */
  const prog = $("#progress"), num = $("#num"), notes = $("#notes"), notesBody = $("#notes-body"), notesH = $("#notes-h")
  let cur = -1
  function fit() {
    SCALE = Math.min(innerWidth / 1920, innerHeight / 1080)
    stage.style.transform = `translate(${-960 * SCALE}px,${-540 * SCALE}px) scale(${SCALE})`
  }
  function go(i, push = true) {
    i = Math.max(0, Math.min(N - 1, i))
    if (i === cur) return
    const prev = cur
    if (prev >= 0 && runs[prev]) runs[prev].stop()
    slides.forEach((s, k) => { s.classList.toggle("active", k === i); s.classList.toggle("prev", k < i) })
    cur = i
    prog.style.width = `${((i + 1) / N) * 100}%`
    num.textContent = `${String(i + 1).padStart(2, "0")} / ${N}`
    const n = $("aside.notes", slides[i])
    notesH.textContent = `${tr("Notes")} · ${i + 1} / ${N} · ${slides[i].dataset.title}`
    notesBody.innerHTML = n ? n.innerHTML : ""
    document.title = `Marvin · ${i + 1}. ${slides[i].dataset.title}`
    if (push) history.replaceState(null, "", `#${i + 1}`)
    target = i * 120 * (window.devicePixelRatio || 1)
    if (reduce) { off = target; draw(0) }
    neb.style.transform = `translateX(${-i * 1.2}%)`
    if (runs[i]) runs[i].play(); else slides[i].dataset.settled = "1"
  }
  const next = () => go(cur + 1), prevS = () => go(cur - 1)
  const fromHash = () => { const k = parseInt(location.hash.slice(1), 10); return Number.isFinite(k) ? k - 1 : 0 }
  function fullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {})
    else document.exitFullscreen?.()
  }
  document.addEventListener("keydown", (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return
    const k = e.key
    if (["ArrowRight", "ArrowDown", "PageDown", " ", "Enter"].includes(k)) { e.preventDefault(); next() }
    else if (["ArrowLeft", "ArrowUp", "PageUp", "Backspace"].includes(k)) { e.preventDefault(); prevS() }
    else if (k === "Home") go(0)
    else if (k === "End") go(N - 1)
    else if (k === "f" || k === "F") fullscreen()
    else if (k === "n" || k === "N") notes.classList.toggle("open")
    else if (k === "Escape") notes.classList.remove("open")
  })
  $$(".chrome [data-nav]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); go(cur + Number(b.dataset.nav)) }))
  $("#viewport").addEventListener("click", (e) => {
    if (e.target.closest("button,a,#notes")) return
    if (e.clientX < innerWidth / 3) prevS(); else next()
  })
  let tx = null, ty = null
  addEventListener("touchstart", (e) => { tx = e.touches[0].clientX; ty = e.touches[0].clientY }, { passive: true })
  addEventListener("touchend", (e) => {
    if (tx == null) return
    const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) { dx < 0 ? next() : prevS() }
    tx = null
  }, { passive: true })
  addEventListener("hashchange", () => go(fromHash(), false))
  addEventListener("resize", () => { fit(); seed(); if (reduce) draw(0) })
  fit()
  go(fromHash(), false)
  if (cur === 0) { const h = $("#hint"); h.classList.add("show"); setTimeout(() => h.classList.remove("show"), 4500) }
  window.__deck = { go: (i) => go(i - 1), get current() { return cur + 1 }, count: N }
})()
