"""Marvin v3 build. Usage: python3 build.py [en|it|all] (default all).
Writes ../marvin-v3.html, ../marvin-v3-it.html and regenerates ../PLACEHOLDERS.md.
Works from any folder that contains this file plus style.css, app.js, body-*.html, data-*.json, strings-it.js."""
import json, pathlib, sys
d = pathlib.Path(__file__).resolve().parent
T = {
  "en": dict(lang="en", body="body-en.html", data="data-en.json", strings=None, out="marvin-v3.html", title="Marvin",
             desc="Marvin: agentic flows that reach the goal, supervised at every decision. Agents do the volume, people make the decisions."),
  "it": dict(lang="it", body="body-it.html", data="data-it.json", strings="strings-it.js", out="marvin-v3-it.html", title="Marvin",
             desc="Marvin: flow agentici che arrivano all'obiettivo, con una persona a ogni decisione. Gli agenti fanno il volume, le persone prendono le decisioni."),
}
FONTS = "https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700;800&family=Geist+Mono:wght@400;500;600&family=Fredoka:wght@600&display=swap"
SLIDES = {"6": "6 · Proof", "7": "7 · Cost and control", "8": "8 · Owners and the ask"}

def build(t):
    c = T[t]
    data = json.loads((d / c["data"]).read_text(encoding="utf-8"))
    strings = (d / c["strings"]).read_text(encoding="utf-8") if c["strings"] else ""
    html = f'''<!doctype html>
<html lang="{c["lang"]}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{c["title"]}</title>
<meta name="description" content="{c["desc"]}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{FONTS}">
<style>
{(d / "style.css").read_text(encoding="utf-8")}
</style>
</head>
<body class="v3">
{(d / c["body"]).read_text(encoding="utf-8")}
<script>
window.MARVIN_DATA = {json.dumps(data, ensure_ascii=False)};
{strings}
{(d / "app.js").read_text(encoding="utf-8")}
</script>
</body>
</html>
'''
    (d.parent / c["out"]).write_text(html, encoding="utf-8")
    print(t, d.parent / c["out"], len(html))

def kind(e):
    return "TO CONFIRM" if e.get("kind") == "confirm" or e.get("suggestion") else "REAL DATA"

def placeholders_md():
    en = json.loads((d / "data-en.json").read_text(encoding="utf-8")); it = json.loads((d / "data-it.json").read_text(encoding="utf-8"))
    rows = [k for k in en if not k.startswith("_")]
    assert set(rows) == {k for k in it if not k.startswith("_")}, "data-en.json and data-it.json must have the same keys"
    open_ = [k for k in rows if not en[k].get("value") or not it[k].get("value")]
    L = ["# Marvin v3: placeholders to fill", "",
         "Every real-data slot in the decks comes from two files: `src/data-en.json` (English) and `src/data-it.json` (Italian).",
         "To fill one, put the text in its `\"value\"` field (in both files), then run `python3 src/build.py`.",
         "An empty `value` is shown on screen as a dashed amber box: `[REAL DATA: …]` / `[DATO REALE: …]`.",
         "Entries marked TO CONFIRM show `[TO CONFIRM: …]` / `[DA CONFERMARE: …]` (plus a suggestion, if any): confirm or replace.",
         "Slide 8 lists are open-ended: add `running_3`, `owner_5`, `next_3`… (with a `term`) to both files and a new row appears.",
         "The speaker notes (in `body-en.html` / `body-it.html`) repeat the same placeholders in square brackets: update them too.",
         "", f"Open: {len(open_)} of {len(rows)} keys.", ""]
    n = 0
    for s in sorted({en[k]["slide"] for k in rows}):
        L += [f"## Slide {SLIDES.get(s, s)}", "",
              "| # | Key | Type | On screen (EN) | What Riccardo must provide | Suggestion | Filled EN / IT |",
              "|---|---|---|---|---|---|---|"]
        for k in [k for k in rows if en[k]["slide"] == s]:
            n += 1; e = en[k]
            term = f"{e['term']}: " if e.get("term") else ""
            L.append(f"| {n} | `{k}` | {kind(e)} | {term}[{kind(e)}: {e['label']}] | {e['hint']} | {e.get('suggestion', '')} | "
                     f"{'yes' if e.get('value') else 'no'} / {'yes' if it[k].get('value') else 'no'} |")
        L.append("")
    L += ["No numbers, costs, dates, names or results appear in the decks except through these keys (Gemini CLI and Riccardo's own role are pre-filled)."]
    (d.parent / "PLACEHOLDERS.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("PLACEHOLDERS.md", len(rows), "keys,", len(open_), "open")

arg = (sys.argv[1:] or ["all"])[0]
for t in (T if arg == "all" else [arg]): build(t)
placeholders_md()
