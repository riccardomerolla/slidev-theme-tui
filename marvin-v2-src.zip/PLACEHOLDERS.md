# Marvin v2: placeholders to fill

Every real-data slot in the decks comes from two files:
`v2/src/data-en.json` (English) and `v2/src/data-it.json` (Italian).
To fill one, put the text in its `"value"` field (in both files), then run `python3 v2/src/build.py`.
An empty `value` is shown on screen as a dashed amber box: `[REAL DATA: …]` / `[DATO REALE: …]`.
Entries with a `suggestion` show `[TO CONFIRM: …]` / `[DA CONFERMARE: …]` plus the suggested text; confirm or replace it.
The speaker notes (in `body-en.html` / `body-it.html`) repeat the same placeholders in square brackets: update them too.

Open: 24 of 24.

| # | Key | Slide / step | On screen (EN) | What Riccardo must provide | Suggestion (to confirm) | Filled EN / IT |
|---|---|---|---|---|---|---|
| 1 | `app_desc` | 2 | [REAL DATA: what the COBOL-J2EE application does, and its size] | One or two lines: business function, number of programs / lines of code / users, as you want them said in the room. |  | no / no |
| 2 | `app_cost` | 2 | [REAL DATA: what keeping it alive costs each year] | Annual run cost (licences, mainframe/hosting, vendor support, people). One figure or a short breakdown, with source. |  | no / no |
| 3 | `rewrite_why` | 2 | [REAL DATA: why a rewrite by hand never happens] | The reasons you confirm, in CREDEM's words. Replace or confirm the suggestion. | the knowledge sits with a few people; behaviour must not change; a manual rewrite would take the same people for years | no / no |
| 4 | `module_name` | 3 (title) | [REAL DATA: anonymized module name] | The anonymized name of the module used in the demo run. |  | no / no |
| 5 | `target_stack` | 3 (title, step 3) | [REAL DATA: target stack] | The new stack / cloud platform the module runs on after the run. |  | no / no |
| 6 | `plan_excerpt` | 3, step 1 | [REAL DATA: excerpt of the approved plan.md (5-8 lines)] | Paste a short, anonymized excerpt of the plan the person approved. |  | no / no |
| 7 | `plan_approver` | 3, step 1 | [REAL DATA: who approved the plan (role)] | Role of the person who approved, e.g. the module owner. No names unless agreed. |  | no / no |
| 8 | `review_finding` | 3, step 2 | [REAL DATA: the gap the review found (text from findings.md)] | Quote the round-1 review finding from the real run, anonymized. |  | no / no |
| 9 | `review_outcome` | 3, step 2 | [REAL DATA: what the revision changed, and the round-2 review result] | One or two lines from findings.md round 2. |  | no / no |
| 10 | `old_output` | 3, step 3 | [REAL DATA: output sample from the old system] | A short anonymized sample of recorded output from the COBOL-J2EE system. |  | no / no |
| 11 | `new_output` | 3, step 3 | [REAL DATA: the same case, output from the new system] | The matching sample from the new system for the same recorded input. |  | no / no |
| 12 | `equivalence_result` | 3, step 3 | [REAL DATA: equivalence result (cases replayed / identical)] | From the equivalence report of the real run. |  | no / no |
| 13 | `diff_summary` | 3, step 3 | [REAL DATA: diff report summary] | What the diff report says: no differences, or the accepted differences and who accepted them. |  | no / no |
| 14 | `coverage_pct` | 3, step 4 | [REAL DATA: coverage %] | Coverage figure from the run's report, with what it measures (lines, branches, rules). |  | no / no |
| 15 | `coverage_scope` | 3, step 4 | [REAL DATA: what the replay and tests cover] | Rules / scenarios / paths covered, in one or two lines. |  | no / no |
| 16 | `coverage_gaps` | 3, step 4 | [REAL DATA: what is not covered, and why] | Known gaps and the reason (out of scope, deferred, accepted by whom). |  | no / no |
| 17 | `result_migrated` | 5 | [REAL DATA: what was migrated] | Module and scope moved to the new stack in this run. |  | no / no |
| 18 | `result_equivalence` | 5 | [REAL DATA: equivalence result] | Same figure as the demo's equivalence report. |  | no / no |
| 19 | `result_coverage` | 5 | [REAL DATA: coverage] | Same figure as the demo's coverage step. |  | no / no |
| 20 | `result_decisions` | 5 | [REAL DATA: decisions made by people in this run] | E.g. plan approval, spec sign-off, accepted differences: what was decided, by which role. |  | no / no |
| 21 | `ask_main` | 5 | [REAL DATA: the decision we ask for today] | One sentence: what you want the room to decide, by when. |  | no / no |
| 22 | `ask_opt1` | 5 | [REAL DATA: option A] | Confirm or replace. Name the module if you ask for it. | approve the next module | no / no |
| 23 | `ask_opt2` | 5 | [REAL DATA: option B] | Confirm or replace. Role or name of the compliance owner. | name a compliance owner for the runs | no / no |
| 24 | `ask_opt3` | 5 | [REAL DATA: option C] | Confirm or replace. Profiles and time you need. | two more people on the team | no / no |

No numbers, costs, coverage figures, module names, findings or diffs appear anywhere in the decks except through these keys.
