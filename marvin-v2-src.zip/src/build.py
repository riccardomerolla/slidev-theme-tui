"""Marvin v2 build. Usage: python3 build.py [en|it|all] (default all). Also regenerates ../PLACEHOLDERS.md."""
import json, pathlib, sys
d = pathlib.Path(__file__).parent
T = {
  "en": dict(lang="en", body="body-en.html", data="data-en.json", strings=None, out="marvin-v2.html", title="Marvin",
             desc="MARVIN moves our legacy to the cloud with AI agents doing the work and our people making every decision."),
  "it": dict(lang="it", body="body-it.html", data="data-it.json", strings="strings-it.js", out="marvin-v2-it.html", title="Marvin",
             desc="MARVIN porta il nostro legacy in cloud: gli agenti AI fanno il lavoro, le nostre persone prendono ogni decisione."),
}
FONTS = "https://fonts.googleapis.com/css2?family=Geist:wght@400;500;600;700;800&family=Geist+Mono:wght@400;500;600&family=Fredoka:wght@600&display=swap"
def build(t):
    c = T[t]
    data = json.loads((d / c["data"]).read_text())
    strings = (d / c["strings"]).read_text() if c["strings"] else ""
    html = f'''<!doctype html>
<html lang="{c["lang"]}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>{c["title"]}</title>
<meta name="description" content="{c["desc"]}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="{FONTS}">
<style>
{(d / "style.css").read_text()}
</style>
</head>
<body>
{(d / c["body"]).read_text()}
<script>
window.MARVIN_DATA = {json.dumps(data, ensure_ascii=False)};
{strings}
{(d / "app.js").read_text()}
</script>
</body>
</html>
'''
    (d.parent / c["out"]).write_text(html)
    print(t, c["out"], len(html))

def placeholders_md():
    en = json.loads((d / "data-en.json").read_text()); it = json.loads((d / "data-it.json").read_text())
    rows = [k for k in en if not k.startswith("_")]
    open_ = [k for k in rows if not en[k].get("value") or not it[k].get("value")]
    L = ["# Marvin v2: placeholders to fill", "",
         "Every real-data slot in the decks comes from two files:",
         "`v2/src/data-en.json` (English) and `v2/src/data-it.json` (Italian).",
         "To fill one, put the text in its `\"value\"` field (in both files), then run `python3 v2/src/build.py`.",
         "An empty `value` is shown on screen as a dashed amber box: `[REAL DATA: …]` / `[DATO REALE: …]`.",
         "Entries with a `suggestion` show `[TO CONFIRM: …]` / `[DA CONFERMARE: …]` plus the suggested text; confirm or replace it.",
         "The speaker notes (in `body-en.html` / `body-it.html`) repeat the same placeholders in square brackets: update them too.",
         "", f"Open: {len(open_)} of {len(rows)}.", "",
         "| # | Key | Slide / step | On screen (EN) | What Riccardo must provide | Suggestion (to confirm) | Filled EN / IT |",
         "|---|---|---|---|---|---|---|"]
    for i, k in enumerate(rows, 1):
        e = en[k]
        L.append(f"| {i} | `{k}` | {e['slide']} | [REAL DATA: {e['label']}] | {e['hint']} | {e.get('suggestion', '')} | {'yes' if e.get('value') else 'no'} / {'yes' if it[k].get('value') else 'no'} |")
    L += ["", "No numbers, costs, coverage figures, module names, findings or diffs appear anywhere in the decks except through these keys."]
    (d.parent / "PLACEHOLDERS.md").write_text("\n".join(L) + "\n")
    print("PLACEHOLDERS.md", len(rows), "keys,", len(open_), "open")

arg = (sys.argv[1:] or ["all"])[0]
for t in (T if arg == "all" else [arg]): build(t)
placeholders_md()
