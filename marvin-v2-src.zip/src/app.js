;(() => {
  "use strict"
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches
  const SPEED = reduce ? 0.02 : 1
  const Cancel = Symbol("cancel")
  const L = window.MARVIN_L || {}
  const tr = (t, v) => { if (t == null) return t; let r = L[t] ?? t; if (v) for (const k in v) r = r.split(`{${k}}`).join(v[k]); return r }
  const $ = (s, r = document) => r.querySelector(s)
  const $$ = (s, r = document) => [...r.querySelectorAll(s)]
  const stage = $("#stage")
  const slides = $$(".slide", stage)
  const N = slides.length
  let SCALE = 1

  const ICONS = {
    star: '<svg viewBox="0 0 24 24"><path d="M12 1.5c.7 5.6 3.4 8.5 10.5 10.5-7.1 2-9.8 4.9-10.5 10.5C11.3 16.9 8.6 14 1.5 12 8.6 10 11.3 7.1 12 1.5z"/></svg>',
    fail: '<svg viewBox="0 0 24 24"><path d="M8 2h8l6 6v8l-6 6H8l-6-6V8zm2.1 5L7 10.1 8.9 12 7 13.9 10.1 17 12 15.1 13.9 17 17 13.9 15.1 12 17 10.1 13.9 7 12 8.9z"/></svg>',
    human: '<svg viewBox="0 0 24 24"><circle cx="12" cy="7.5" r="4"/><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4.2" height="16" rx="1.2"/><rect x="13.8" y="4" width="4.2" height="16" rx="1.2"/></svg>'
  }
  const ARROW = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13.3 4.3a1 1 0 0 1 1.4 0l7 7a1 1 0 0 1 0 1.4l-7 7a1 1 0 0 1-1.4-1.4l5.3-5.3H3a1 1 0 1 1 0-2h15.6l-5.3-5.3a1 1 0 0 1 0-1.4z"/></svg>'
  const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e }
  const fmt = (sim) => { const s = Math.round(sim); return `${Math.floor(s / 60)}m ${String(s % 60).padStart(2, "0")}s` }
  const rel = (node, base) => { const a = node.getBoundingClientRect(), b = base.getBoundingClientRect(); return { x: (a.left - b.left) / SCALE, y: (a.top - b.top) / SCALE, w: a.width / SCALE, h: a.height / SCALE } }

  /* ── node (after visual-effect's EffectNode) ── */
  function makeNode(name, sub, opts = {}) {
    name = tr(name); sub = tr(sub)
    const root = el("div", "ve" + (opts.h ? " h" : ""))
    const bubble = el("div", "ve-bubble"); bubble.hidden = true
    const box = el("div", "ve-box"), shine = el("div", "ve-shine"), content = el("div", "ve-content")
    box.append(shine, content)
    const label = el("div", "ve-label"), nm = el("span", "ve-name", name), sb = el("span", "ve-sub", sub || ""), time = el("span", "ve-time")
    label.append(nm); if (sub != null) label.append(sb); label.append(time)
    root.append(bubble, box, label)
    let raf = 0, t0 = 0, bt = 0
    const stopTimer = () => { cancelAnimationFrame(raf); raf = 0 }
    const tick = () => { time.textContent = fmt(((performance.now() - t0) / 1000) * 240); raf = requestAnimationFrame(tick) }
    const pop = (n) => { if (!reduce && n) n.animate([{ transform: "scale(.5)", opacity: 0, filter: "blur(8px)" }, { transform: "scale(1)", opacity: 1, filter: "blur(0)" }], { duration: 460, easing: "cubic-bezier(.34,1.56,.64,1)" }) }
    const icon = (k) => { content.innerHTML = `<span class="ve-icon">${ICONS[k]}</span>`; pop(content.firstChild) }
    const width = (w) => { box.style.width = `${w}px` }
    const hideBubble = () => { clearTimeout(bt); bubble.hidden = true }
    const showBubble = (text, kind, ms) => {
      clearTimeout(bt)
      bubble.className = `ve-bubble ${kind}`; bubble.textContent = text; bubble.hidden = false
      if (!opts.h) {
        bubble.style.left = "0px"; bubble.style.setProperty("--tip", "42px")
        const card = root.closest(".card")
        if (card) {
          const cr = card.getBoundingClientRect(), r = bubble.getBoundingClientRect()
          const over = (r.right - (cr.right - 16 * SCALE)) / SCALE
          if (over > 0) { bubble.style.left = `${-over}px`; bubble.style.setProperty("--tip", `${42 + over}px`) }
        }
      }
      if (!reduce) bubble.animate([{ opacity: 0, scale: ".9" }, { opacity: 1, scale: "1" }], { duration: 260, easing: "cubic-bezier(.34,1.56,.64,1)" })
      if (ms) bt = setTimeout(() => { bubble.hidden = true }, ms * SPEED + (reduce ? 0 : 0))
    }
    const shake = () => { if (!reduce) box.animate([0, 8, -8, 6, -6, 3, 0].map((x, i) => ({ transform: `translateX(${x}px) rotate(${i % 2 ? 4 : -4}deg)` })), { duration: 480, easing: "ease-out" }) }
    const api = {
      root, box,
      idle() { stopTimer(); hideBubble(); time.textContent = ""; box.dataset.state = "idle"; width(84); icon("star") },
      run() { hideBubble(); box.dataset.state = "running"; width(84); content.innerHTML = ""; t0 = performance.now(); stopTimer(); if (!reduce) tick() },
      done(text) { stopTimer(); hideBubble(); time.textContent = ""; box.dataset.state = "done"; const s = el("span", null, tr(text)); content.innerHTML = ""; content.append(s); width(Math.max(84, s.scrollWidth + 40)); pop(s) },
      fail(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "failed"; icon("fail"); shake(); showBubble(tr(msg), "fail") },
      wait(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "human"; width(84); icon("human"); showBubble(tr(msg), "human") },
      interrupt(msg) { stopTimer(); time.textContent = ""; box.dataset.state = "interrupted"; icon("pause"); shake(); showBubble(tr(msg), "interrupted") },
      note(msg, ms = 1800) { showBubble(tr(msg), "note", ms) },
      hide: hideBubble,
      flash() { if (!reduce) box.animate([{ filter: "brightness(2)" }, { filter: "brightness(1)" }], { duration: 560 }) },
      label(t) { nm.textContent = tr(t) }, sublabel(t) { sb.textContent = tr(t) }
    }
    api.idle()
    return api
  }

  /* ── simulated presenter cursor ── */
  const cursor = $("#cursor")
  let cursorPos = { x: 1500, y: 900 }
  async function clickOn(btn, c) {
    const r = rel(btn, stage)
    const tx = r.x + r.w * 0.6, ty = r.y + r.h * 0.62
    if (!reduce) {
      cursor.style.transition = "none"
      cursor.style.transform = `translate(${cursorPos.x}px,${cursorPos.y}px)`
      cursor.classList.add("on")
      await c.sleep(60)
      cursor.style.transition = "transform .75s cubic-bezier(.5,0,.2,1), opacity .3s"
      cursor.style.transform = `translate(${tx}px,${ty}px)`
      await c.sleep(800)
      cursor.classList.remove("click"); void cursor.offsetWidth; cursor.classList.add("click")
    }
    cursorPos = { x: tx, y: ty }
    btn.classList.add("pressed")
    await c.sleep(220)
    btn.classList.remove("pressed")
    if (!reduce) setTimeout(() => cursor.classList.remove("on"), 700)
  }


  /* ── placeholders: every real-data slot comes from data-<lang>.json ── */
  const DATA = window.MARVIN_DATA || {}
  const META = DATA._meta || { real: "REAL DATA", confirm: "TO CONFIRM", suggested: "suggested" }
  const esc = (t) => String(t).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[m])
  function fillPlaceholders() {
    for (const e of $$("[data-ph]")) {
      const d = DATA[e.dataset.ph]
      if (!d) { e.textContent = `[MISSING KEY: ${e.dataset.ph}]`; e.classList.add("ph"); continue }
      if (d.value) { e.textContent = d.value; e.classList.add("filled"); continue }
      e.classList.add("ph")
      const kind = d.suggestion ? META.confirm : META.real
      e.innerHTML = `<span class="ph-l">[${esc(kind)}: ${esc(d.label)}]</span>` + (d.suggestion ? `<span class="ph-s">${esc(META.suggested)}: ${esc(d.suggestion)}</span>` : "")
      e.title = d.hint || ""
    }
  }
  fillPlaceholders()

  /* ── run context per slide, with optional steps ── */
  function makeRun(slide, scenario) {
    let gen = 0, doneStep = -1, busy = false
    const nodes = []
    const c = {
      root: slide, fast: false,
      node(name, sub, opts) { const n = makeNode(name, sub, opts); nodes.push(n); return n },
      arrow() { return el("div", "arrow", ARROW) },
      chain(parent, list) { list.forEach((n, i) => { if (i) parent.append(c.arrow()); parent.append(n.root) }) },
      sleep(ms) { const g = gen; return new Promise((res, rej) => setTimeout(() => (g === gen ? res() : rej(Cancel)), c.fast ? 0 : ms * SPEED)) },
      async press(btn, waitMs = 1600) {
        const g = gen
        if (!c.fast) {
          btn.disabled = false; btn.classList.add("ready")
          await c.sleep(waitMs)
          await clickOn(btn, c)
        }
        if (g !== gen) throw Cancel
        btn.disabled = true; btn.classList.remove("ready"); btn.classList.add("used")
      },
      reveal(sel) { $$(sel, slide).forEach((e) => e.classList.add("shown")) },
      reset() {
        gen++; doneStep = -1
        nodes.forEach((n) => n.idle())
        $$("button[data-act]", slide).forEach((b) => { b.disabled = true; b.classList.remove("ready", "pressed", "used") })
        $$(".shown", slide).forEach((e) => e.classList.remove("shown"))
        cursor.classList.remove("on")
        scenario.reset && scenario.reset(c)
      }
    }
    scenario.build && scenario.build(c)
    c.reset()
    const show = (s) => {
      $$("[data-panel]", slide).forEach((p) => p.classList.toggle("on", Number(p.dataset.panel) === s))
      $$(".stepper li", slide).forEach((li, k) => { li.classList.toggle("on", k === s); li.classList.toggle("past", k < s) })
    }
    return {
      async play(s = 0) {
        slide.dataset.settled = "0"
        show(s)
        const g0 = gen
        try {
          if (scenario.steps) {
            if (!(s === doneStep + 1 && !busy)) {
              c.reset()
              c.fast = true
              for (let j = 0; j < s; j++) await scenario.step(c, j)
              c.fast = false
            }
            busy = true
            const g = gen
            await c.sleep(s === 0 ? scenario.delay ?? 900 : 500)
            await scenario.step(c, s)
            if (g === gen) { doneStep = s; busy = false; slide.dataset.settled = "1"; slide.dataset.settledStep = String(s) }
          } else {
            c.reset()
            const g = gen
            await c.sleep(scenario.delay ?? 900)
            await scenario.run(c)
            if (g === gen) { slide.dataset.settled = "1"; slide.dataset.settledStep = "0" }
          }
        } catch (e) { busy = false; c.fast = false; if (e !== Cancel) console.error(e) }
      },
      stop() { c.reset(); busy = false; slide.dataset.settled = "0" }
    }
  }

  /* ── scenarios, keyed by slide number ── */
  const S = {}

  S[1] = { delay: 300, async run() { } }

  S[2] = { delay: 300, async run(c) { await c.sleep(1800) } }

  // The demo: one real run, four steps advanced with the clicker.
  S[3] = {
    steps: 4,
    build(c) {
      const row = $("[data-row]", c.root)
      const G = "Gemini CLI"
      this.n = {
        plan: c.node("plan", G), you: c.node("you", "a person"), build: c.node("build", G), checks: c.node("checks", "our tests"),
        review: c.node("review", G), replay: c.node("replay", "recorded"), cov: c.node("coverage", "report"), commit: c.node("commit", "reviewed")
      }
      c.chain(row, Object.values(this.n))
      this.approve = $('[data-act="approve"]', c.root)
    },
    async step(c, s) {
      const n = this.n
      if (s === 0) {
        n.plan.run(); await c.sleep(1300); n.plan.done("plan.md"); c.reveal('[data-r="p1"]')
        n.you.wait("Read the plan, then decide")
        await c.press(this.approve, 2200)
        n.you.done("approved"); c.reveal('[data-r="p2"]')
      } else if (s === 1) {
        n.build.run(); await c.sleep(1300); n.build.done("code")
        n.checks.run(); await c.sleep(900); n.checks.done("✓")
        n.review.run(); await c.sleep(1100); n.review.fail("Gap found → findings.md"); c.reveal('[data-r="f1"]')
        await c.sleep(2200)
        n.checks.idle(); n.review.idle()
        n.build.run(); n.build.note("Revision", 1300); c.reveal('[data-r="f2"]')
        await c.sleep(1300); n.build.done("revised")
        n.checks.run(); await c.sleep(800); n.checks.done("✓")
        n.review.run(); await c.sleep(1000); n.review.done("accepted"); c.reveal('[data-r="f3"]')
      } else if (s === 2) {
        n.replay.run(); c.reveal('[data-r="c1"]')
        await c.sleep(2600); n.replay.done("report"); c.reveal('[data-r="c2"]')
      } else if (s === 3) {
        n.cov.run(); c.reveal('[data-r="v1"]'); await c.sleep(1800); n.cov.done("report"); c.reveal('[data-r="v2"]')
        n.commit.run(); await c.sleep(800); n.commit.done("commit")
      }
    }
  }

  S[4] = {
    build(c) {
      const [r1, r2, r3] = $$("[data-mini] [data-row]", c.root)
      this.st = [c.node("story 1"), c.node("story 2"), c.node("story 3")]
      this.br = c.node("branch")
      this.st.forEach((n) => r1.append(n.root)); r1.append(c.arrow(), this.br.root)
      this.t = [c.node("task 1"), c.node("task 2"), c.node("task 3")]
      c.chain(r2, this.t)
      this.g = [c.node("plan", "Gemini CLI"), c.node("code", "Gemini CLI"), c.node("review", "Gemini CLI")]
      c.chain(r3, this.g)
    },
    async run(c) {
      const a = async () => {
        this.st.forEach((n) => n.run()); this.br.run()
        await c.sleep(1100); this.st[0].done("judge ✓")
        await c.sleep(500); this.st[2].done("judge ✓")
        await c.sleep(600); this.st[1].done("judge ✓")
        await c.sleep(300); this.br.done("merged")
      }
      const b = async () => {
        await c.sleep(300)
        this.t[0].run(); await c.sleep(900); this.t[0].done("✓")
        this.t[1].run(); await c.sleep(900); this.t[1].interrupt("Paused")
        await c.sleep(1400); this.t[1].run(); this.t[1].note("Resumed from the progress file", 1800)
        await c.sleep(1000); this.t[1].done("✓")
        this.t[2].run(); await c.sleep(900); this.t[2].done("✓")
      }
      const d = async () => {
        await c.sleep(600)
        for (const n of this.g) { n.run(); await c.sleep(800); n.done("✓") }
      }
      await Promise.all([a(), b(), d()])
    }
  }

  S[5] = {
    build(c) { this.h = c.node("you", "decide", {}); $("[data-asknode]", c.root).append(this.h.root) },
    async run(c) {
      for (let i = 1; i <= 5; i++) { c.reveal(`[data-r="s${i}"]`); await c.sleep(350) }
      await c.sleep(300)
      this.h.wait("Your decision"); c.reveal('[data-r="ask"]')
      await c.sleep(1200)
    }
  }

  const runs = slides.map((s, i) => (S[i + 1] ? makeRun(s, S[i + 1]) : null))
  /* ── starfield with parallax ── */
  const cv = $("#stars"), ctx = cv.getContext("2d"), neb = $(".nebula")
  let stars = [], W = 0, H = 0, off = 0, target = 0, last = 0
  function seed() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    W = cv.width = Math.floor(innerWidth * dpr); H = cv.height = Math.floor(innerHeight * dpr)
    let r = 1337; const rnd = () => ((r = (r * 16807) % 2147483647) / 2147483647)
    stars = Array.from({ length: Math.round((innerWidth * innerHeight) / 5200) }, () => {
      const z = rnd() ** 2 * 0.9 + 0.1
      return { x: rnd() * W, y: rnd() * H, z, r: (0.4 + z * 1.4) * dpr, p: rnd() * 6.28, g: rnd() < 0.12 }
    })
  }
  function draw(t) {
    ctx.clearRect(0, 0, W, H)
    for (const s of stars) {
      let x = (s.x - off * s.z * 3) % W; if (x < 0) x += W
      const tw = reduce ? 0.8 : 0.55 + 0.45 * Math.sin(t / 900 + s.p)
      ctx.globalAlpha = (0.25 + s.z * 0.75) * tw
      ctx.fillStyle = s.g ? "#9ff5b8" : "#e8eef7"
      ctx.beginPath(); ctx.arc(x, s.y, s.r, 0, 6.283); ctx.fill()
    }
    ctx.globalAlpha = 1
  }
  function loop(t) { off += (target - off) * 0.05; draw(t); last = requestAnimationFrame(loop) }
  seed()
  if (reduce) draw(0); else requestAnimationFrame(loop)


  /* ── deck: slides and steps ── */
  const prog = $("#progress"), num = $("#num"), notes = $("#notes"), notesBody = $("#notes-body"), notesH = $("#notes-h")
  const stepsOf = (i) => Number(slides[i].dataset.steps || 1)
  const positions = []
  slides.forEach((_, i) => { for (let s = 0; s < stepsOf(i); s++) positions.push([i, s]) })
  let cur = -1, step = 0
  function fit() {
    SCALE = Math.min(innerWidth / 1920, innerHeight / 1080)
    stage.style.transform = `translate(${-960 * SCALE}px,${-540 * SCALE}px) scale(${SCALE})`
  }
  function go(i, s = 0, push = true) {
    i = Math.max(0, Math.min(N - 1, i))
    const n = stepsOf(i)
    s = s < 0 ? n - 1 : Math.min(s, n - 1)
    if (i === cur && s === step) return
    const prev = cur
    if (prev >= 0 && prev !== i && runs[prev]) runs[prev].stop()
    slides.forEach((x, k) => { x.classList.toggle("active", k === i); x.classList.toggle("prev", k < i) })
    cur = i; step = s
    slides[i].dataset.step = String(s)
    const pos = positions.findIndex(([a, b]) => a === i && b === s)
    prog.style.width = `${((pos + 1) / positions.length) * 100}%`
    num.textContent = `${String(i + 1).padStart(2, "0")} / ${String(N).padStart(2, "0")}` + (n > 1 ? ` · ${tr("step")} ${s + 1}/${n}` : "")
    const nt = $(`aside.notes[data-step="${s}"]`, slides[i]) || $("aside.notes", slides[i])
    notesH.textContent = `${tr("Notes")} · ${i + 1}${n > 1 ? "." + (s + 1) : ""} · ${slides[i].dataset.title}`
    notesBody.innerHTML = nt ? nt.innerHTML : ""
    document.title = `Marvin · ${i + 1}. ${slides[i].dataset.title}`
    if (push) history.replaceState(null, "", `#${i + 1}${n > 1 ? "." + (s + 1) : ""}`)
    target = pos * 90 * (window.devicePixelRatio || 1)
    if (reduce) { off = target; draw(0) }
    neb.style.transform = `translateX(${-pos * 1}%)`
    if (runs[i]) runs[i].play(s); else { slides[i].dataset.settled = "1"; slides[i].dataset.settledStep = String(s) }
  }
  const next = () => (step < stepsOf(cur) - 1 ? go(cur, step + 1) : go(cur + 1, 0))
  const prevS = () => (step > 0 ? go(cur, step - 1) : go(cur - 1, -1))
  const fromHash = () => { const [a, b] = location.hash.slice(1).split("."); const k = parseInt(a, 10), t = parseInt(b, 10); return [Number.isFinite(k) ? k - 1 : 0, Number.isFinite(t) ? t - 1 : 0] }
  function fullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {})
    else document.exitFullscreen?.()
  }
  document.addEventListener("keydown", (e) => {
    if (e.metaKey || e.ctrlKey || e.altKey) return
    const k = e.key
    if (["ArrowRight", "ArrowDown", "PageDown", " ", "Enter"].includes(k)) { e.preventDefault(); next() }
    else if (["ArrowLeft", "ArrowUp", "PageUp", "Backspace"].includes(k)) { e.preventDefault(); prevS() }
    else if (k === "Home") go(0)
    else if (k === "End") go(N - 1, -1)
    else if (k === "f" || k === "F") fullscreen()
    else if (k === "n" || k === "N") notes.classList.toggle("open")
    else if (k === "Escape") notes.classList.remove("open")
  })
  $$(".chrome [data-nav]").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); Number(b.dataset.nav) > 0 ? next() : prevS() }))
  $("#viewport").addEventListener("click", (e) => {
    if (e.target.closest("button,a,#notes")) return
    if (e.clientX < innerWidth / 3) prevS(); else next()
  })
  let tx = null, ty = null
  addEventListener("touchstart", (e) => { tx = e.touches[0].clientX; ty = e.touches[0].clientY }, { passive: true })
  addEventListener("touchend", (e) => {
    if (tx == null) return
    const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) { dx < 0 ? next() : prevS() }
    tx = null
  }, { passive: true })
  addEventListener("hashchange", () => { const [a, b] = fromHash(); go(a, b, false) })
  addEventListener("resize", () => { fit(); seed(); if (reduce) draw(0) })
  fit()
  { const [a, b] = fromHash(); go(a, b, false) }
  if (cur === 0) { const h = $("#hint"); h.classList.add("show"); setTimeout(() => h.classList.remove("show"), 4500) }
  window.__deck = { go: (i, s = 0) => go(i - 1, s), get current() { return [cur + 1, step] }, count: N, positions: positions.map(([a, b]) => [a + 1, b]) }
})()
