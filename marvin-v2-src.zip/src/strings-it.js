window.MARVIN_L = {
  "Notes": "Note", "step": "passo",
  "plan": "piano", "you": "tu", "a person": "una persona", "build": "build", "checks": "controlli", "our tests": "i nostri test",
  "review": "review", "replay": "replay", "recorded": "registrato", "coverage": "copertura", "report": "report",
  "commit": "commit", "reviewed": "revisionato",
  "plan.md": "plan.md", "Read the plan, then decide": "Leggi il piano, poi decidi", "approved": "approvato",
  "code": "codice", "Gap found → findings.md": "Lacuna trovata → findings.md", "Revision": "Revisione",
  "revised": "rivisto", "accepted": "accettato",
  "story 1": "story 1", "story 2": "story 2", "story 3": "story 3", "branch": "branch", "judge ✓": "giudice ✓", "merged": "integrato",
  "task 1": "task 1", "task 2": "task 2", "task 3": "task 3", "Paused": "In pausa", "Resumed from the progress file": "Ripreso dal file di avanzamento",
  "decide": "decidete", "Your decision": "Decidete voi"
}
